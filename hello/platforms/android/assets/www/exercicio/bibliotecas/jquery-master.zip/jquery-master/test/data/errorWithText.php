<?php

header("HTTP/1.0 400 Bad Request");

echo "plain text message";